---
layout: post
title: ROOT Package Manager 
subtitle: 
tags: ['CERN-HSF','Google Summmer of Code','ROOT']
---

It seems like it was like yesterday when I said "Hi" to the community but time flies turning me to a Google Summer of Code student. It has been a remarkable journey from a newcomer in open source to a contributor working for the development of the community :)  

My task for GSoC is to work on ROOT Package Manager with my mentors Oksana Shadura, Vassil Vassilev and Brian Bockelman. 
After learning about the existing package managers, further I will work on adding additional functionality using
package manager over the minimal base install of core features. This also involves defining ROOT modules, packages and 
package manager, mainly to scale the large codebase of the project. ROOT is used by different scientific groups and communities for their own purposes. It provides lot of functionalities so as to serve the overall userbase. This task mainly involves simplification of the monolithic ROOT application build process so as to serve the required purpose as per the community requirement rather than building the whole application with all the functionalities.

I will continue writing about my progress in the coming months. Looking forward to a great summer :)



